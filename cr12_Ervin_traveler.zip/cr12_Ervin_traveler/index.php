
<?php get_header(); ?>
   <div class="d-flex post_box">
      <div id="post_container">
      <div class="blog_header text-center m-4">
            <h1><?php bloginfo('name'); ?></h1>
            <p class="lead blog-description"><?php bloginfo('description'); ?></p>
      </div>
      <hr>
         <?php if(have_posts()) : ?> <!--  If there are posts available  -->
            <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop -->
            <div class="accordion m-4" id="accordionExample">
               <div class="card blog_card">
                  <div class="card-header bg-dark" id="headingOne">
                     <h2 class="mb-0">
                     <button class="btn btn-link btn-block text-left p-0" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        <a class="h2" href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
                           <?php the_title(); ?><!--retrieves blog title-->
                        </a>
                     </button>
                     </h2>
                     <p class="text-white"><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->
                  </div>

                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                     <div class="card-body text-justify">
                        <p><?php the_excerpt(); ?></p><!--retrieves content-->
                        <div class="d-flex justify-content-end">
                           <p>Author: <b><?php the_author(); ?></b></p><!--retrieves author of blog entry-->
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         <?php endwhile; ?><!--end the while loop-->
         <?php else :?> <!-- if no posts are found then: -->

            <p>No posts found</p>  <!-- no posts found displayed -->
         <?php endif; ?> <!-- end if -->
      </div>
      <div class="d-flex flex-column sidebar-module">
         <?php 
               if(is_active_sidebar('sidebar')):
                  dynamic_sidebar('Sidebar-Blog');
               endif;
         ?>
      </div>
   </div>
<?php get_footer(); ?>
