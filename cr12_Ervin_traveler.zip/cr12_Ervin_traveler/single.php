<?php get_header(); ?>
   
<div id="single_post">
       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop -->

        <h1><?php the_title(); ?> </h1><!--retrieves blog title-->
        <?php if(has_post_thumbnail()): ?>
			<?php the_post_thumbnail(); ?>
	   <?php endif; ?>

       <p><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->
       
       <p><?php the_content(); ?></p><!--retrieves content-->

       <div class="d-flex justify-content-end">
            <p>Author: <?php the_author(); ?></p><!--retrieves author of blog entry-->
       </div>
       <hr>
       <div class="blog-post-comment">
		<?php comments_template(); ?>
	  </div>

       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>
       <?php endif; ?> <!-- end if -->
</div>

 <?php get_footer(); ?>