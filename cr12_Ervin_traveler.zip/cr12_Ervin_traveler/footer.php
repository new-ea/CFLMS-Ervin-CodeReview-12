
<?php wp_footer(); ?>
<footer class="blog-footer d-flex flex-column">
	<div class="footer-content">
		<p>&copy; <?php echo Date('Y'); ?><?php echo " - " ?> <?php bloginfo('name'); ?></p>
    </div>
    <div class="d-flex p-3">
        <?php 
            if(is_active_sidebar('sidebar')):
                dynamic_sidebar('Sidebar-Footer');
            endif;
        ?>
    </div>
</footer>
</body>

</html>