<?php 

function codefactory_files(){

    //register jQuery
    wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.5.0.min.js', array(),'1.0', true);
    // register bootstrap.css file
    wp_enqueue_style('bootstrap-css', get_template_directory_uri().'/css/bootstrap.css');
    // register bootstrap.js file
    wp_enqueue_script('bootstrap-js', get_template_directory_uri().'/js/bootstrap.js', array(),'1.0', true);
    // register style.css file
    wp_enqueue_style('my-style-sheet', get_template_directory_uri().'/style.css');

}

//add the action of calling codefactory_files when the scripts are loaded
add_action('wp_enqueue_scripts', 'codefactory_files');

/**
* Register Custom Navigation Walker
*/
function register_navwalker(){

    // register the navwalker file
    require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

    register_nav_menus( array(
'primary' => __( 'Top-Menu'),
) );
}

add_action( 'after_setup_theme', 'register_navwalker' );

add_theme_support('post-thumbnails');


function register_widgets() {
    register_sidebar(array(
        'name' => 'Sidebar-Blog',
        'id' => 'sidebar1',
        'before_widget' => '<div class="sidebar">',
        'after_widget' => '</div><hr>',
        'before_title' => '<h2>',
        'after_title' => '</h2>'
    ));

    register_sidebar(array(
        'name' => 'Sidebar-Footer',
        'id' => 'sidebar2',
        'before_widget' => '<div class="sidebar">',
        'after_widget' => '</div><hr>',
        'before_title' => '<h2>',
        'after_title' => '</h2>'
    ));
} 

add_action('widgets_init','register_widgets');