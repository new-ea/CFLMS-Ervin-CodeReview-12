<?php get_header(); ?>   
<div class="container-fluid">
      <div class="blog_header text-center m-4">
            <h1><?php bloginfo('name'); ?></h1>
            <p class="lead blog-description"><?php bloginfo('description'); ?></p>
      </div>
      <hr>
      <div class="container">
            <div class="pageheader">
                  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                  <h1 class="title"><?php the_title(); ?></h1>
            </div>
            <br>
            <div class="entry">
                  <?php the_content(); ?>
            </div>
            <?php endwhile; endif; ?>
      </div> <!-- end of container -->
</div> <!-- end of container-fluid --> 
 <?php get_footer(); ?>
